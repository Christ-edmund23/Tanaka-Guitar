// unit tests
unit_test();
const sleep = ms => new Promise(r => setTimeout(r, ms));
//
const form = document.getElementById('form');
const username_field = document.getElementById('username');
const email_field = document.getElementById('email');
const address_field = document.getElementById('address');
// even though gender's element is a fieldset, it shouldnt require much
// modifications since its parentElement will be the same as other field 
// which is formControl
const gender_field_set = document.getElementById('gender');


function assert_equal(expected, actual) {
	if (expected !== actual) {
		alert(`Test fail expected is 
    \"${expected}\" but got \"${actual}\"`)
	}

}
/** 
 * 
 * 
 * [expect_map_obj]  are plain object like
 * {"a":4,"b":5}, so that it will be easier to pass as an argument
*/
function assert_map(expected_map_obj, actual_map) {
	//convert raw object into map
	var expected_map = new Map(Object.entries(expected_map_obj))
	//
	var expected_val;
	if (expected_map.size !== actual_map.size) {
		alert("Test fail, map is unequal in size");
		return;
	}
	for (var [key, val] of expected_map) {
		expected_val = actual_map.get(key);
		// in cases of an undefined value, make sure the key
		// actually exists on the object so there are no false positives
		if (expected_val !== val ||
			(expected_val === undefined && !actual_map.has(key))) {
			alert("Test fail, map is unequal in value")
			return;
		}
	}
}
function unit_test() {
	console.log("test")
	//
	assert_equal("yes", "yes");
	assert_equal("no", "no");
	assert_equal(true, true);
	// test [is_char_alpha_or_numeric]
	assert_equal(true, is_char_alpha_or_numeric('c'));
	assert_equal(true, is_char_alpha_or_numeric('Z'));
	assert_equal(true, is_char_alpha_or_numeric('8'));
	assert_equal(true, is_char_alpha_or_numeric('1'));
	//
	assert_equal(false, is_char_alpha_or_numeric('@'));
	assert_equal(false, is_char_alpha_or_numeric('!'));
	assert_equal(false, is_char_alpha_or_numeric('*'));
	assert_equal(false, is_char_alpha_or_numeric('='));


	//  test str_get_chars_counts
	assert_map({ ".": 1, "@": 1, "n": 1 }, str_get_chars_counts("n@."))
	assert_map({ ".": 3, "@": 3, "n": 1 }, str_get_chars_counts("n@@@..."))
	// test is_email_valid
	assert_equal(false, is_email_valid("thiscom"));
	assert_equal(false, is_email_valid("nicholas@."));
	assert_equal(false, is_email_valid("nicholas@.c"));
	assert_equal(false, is_email_valid("@.c"));
	assert_equal(false, is_email_valid("@@.c"));
	assert_equal(false, is_email_valid("chris@@.c"));
	assert_equal(false, is_email_valid("chris@..c"));
	assert_equal(false, is_email_valid("chris@.."));
	assert_equal(false, is_email_valid("chris@....com"));
	assert_equal(false, is_email_valid("chris@gmail"));
	assert_equal(false, is_email_valid("chris@gmail"));
	assert_equal(false, is_email_valid("my_name@gmail.com (Nichol)"));
	assert_equal(false, is_email_valid("my_name@gmail.com (something)"));
	assert_equal(false, is_email_valid("#@%^%#$@#$@#.com"));
	assert_equal(false, is_email_valid("あいうえお@example.com"));

	// falsey

	assert_equal(true, is_email_valid("my_email@gmail.com"));
	assert_equal(true, is_email_valid("my_email@domain_example.com"));
	assert_equal(true, is_email_valid("nicholas10@gmail.com"));
	assert_equal(true, is_email_valid("email@example.museum"));
	assert_equal(true, is_email_valid("email@example.co.jp"));
	assert_equal(true, is_email_valid("firstname-lastname@example.com"));
	assert_equal(true, is_email_valid("1234567890@example.com"));
	assert_equal(true, is_email_valid("email@123.123.123.123"));
	assert_equal(true, is_email_valid("email@subdomain.example.com"));

	// 


}

/**ch is a character 
 * returns true if ch is either an alphabet or numeric
 * 
 * 
*/
function is_char_alpha_or_numeric(ch) {
	var ascii_code = ch.toUpperCase().charCodeAt();

	return (ascii_code > 64 && ascii_code < 91) // upper alpha
		|| (ascii_code > 47 && ascii_code < 58); // number
	;

}
// returns a map with each character as key and the value are their's count
function str_get_chars_counts(str) {

	var char_count_map = {};
	for (var i = 0; i < str.length; i++) {
		var char = str.charAt(i);
		var current_char_count = char_count_map[char];
		// char previously haven't been found? 
		if (current_char_count === undefined)
			char_count_map[char] = 1;
		else
			char_count_map[char] = current_char_count + 1;

	}
	return new Map(Object.entries(char_count_map));

}
function is_email_valid(email_str) {
	/** =============== check email's whole part====== */
	// email must not contian whitespace
	if ((email_str.indexOf(' ') >= 0))
		return false;

	//
	var char_count_map = str_get_chars_counts(email_str);

	// check if email has '@' and '.' 
	if (!char_count_map.has("@") || !char_count_map.has("."))
		return false;
	if (char_count_map.get("@") > 1 || char_count_map.get("@") == 0)
		return false;
	//

	var email_str_splitted = email_str.split("@");
	if (email_str_splitted.length != 2)
		return false;

	var email_name = email_str_splitted[0];
	var email_domain = email_str_splitted[1];

	if (email_name.length == 0 || email_domain.length == 0)
		return false;


	var email_name_char_count_map = str_get_chars_counts(email_name);
	var email_domain_char_count_map = str_get_chars_counts(email_domain);
	/**=========check email's name =======================*/

	// first and char of email's name must be either char or number
	if (!is_char_alpha_or_numeric(email_name[0]) &&
		!is_char_alpha_or_numeric(email_name[email_name.length - 1])
	) return false;


	/**================ check email domain ============== */
	// domain must have atleast 1 "."
	if (!email_domain_char_count_map.has("."))
		return false;

	// domain must be at least contains one "." and a character between '@' and '.'
	// and the must at least contain characters between the dots (alphanumeric)
	// like @gmail.com
	var email_domain_splitted_by_dot = email_domain.split(".");
	if (email_domain_splitted_by_dot.length == 1)
		return false;
	for (var i = 0; i < email_domain_splitted_by_dot.length; i++) {
		//character between the dot can't be empty
		if (email_domain_splitted_by_dot[i].length == 0)
			return false;
		// character between the '.' cant be symbols
		if (!is_char_alpha_or_numeric((email_domain_splitted_by_dot[i][0]))) return false;

	}



	if (email_domain_splitted_by_dot[0].length == 0 ||
		email_domain_splitted_by_dot[1].length == 0
	)
		return false;


	/**=================================================== */


	return true;




}
function showError(input, message) {
	const formControl = input.parentElement;
	formControl.className = 'form-control error';
	const small = formControl.querySelector('small');
	small.innerText = message;
}

function showSuccess(input) {
	const formControl = input.parentElement;
	formControl.className = 'form-control success';
}

function CheckEmailField(input) {
	if (is_email_valid(input.value.trim())) {
		showSuccess(input);
		return true;
	} else {
		showError(input, 'Email is not valid');
		return false;
	}
}

function is_fieldset_with_radio_options_empty(fieldset) {
	var options_arr = fieldset.elements;
	for (var i = 0; i < options_arr.length; i++) {
		// if one of option is checked, then it is not empty
		if (options_arr[i].checked) return false;
	}
	return true;

}

// Check required fields
function has_field_been_filled(inputArr) {
	var has_been_filled_count = 0;
	inputArr.forEach(function (input) {
		var field_is_empty = false;
		// gender_field is the only one with different type,
		// so naturally the handling must be different as well
		if (input == gender_field_set) {
			field_is_empty = is_fieldset_with_radio_options_empty(input);
		}
		else {
			field_is_empty = input.value.trim() === '';
		}
		if (field_is_empty) {
			showError(input, `${getFieldName(input)} is required`);
		} else {
			has_been_filled_count++;
			showSuccess(input);
		}
	});
	// check if all field has been field
	return inputArr.length == has_been_filled_count;
}

// return true if field is between min and max (exclusive)
function CheckInputFieldLength(input, min, max) {
	if (input.value.length < min) {
		showError(
			input,
			`${getFieldName(input)} must be at least ${min} characters`
		);
		return false;
	} else if (input.value.length > max) {
		showError(
			input,
			`${getFieldName(input)} must be less than ${max} characters`
		);
		return false
	} else {
		showSuccess(input);
		return true;
	}
}


function getFieldName(field_input) {
	return field_input.id.charAt(0).toUpperCase() + field_input.id.slice(1);
}

// Event listeners
form.addEventListener('submit', async function (e) {
	e.preventDefault();

	if (has_field_been_filled([username_field, email_field, address_field, gender_field_set])) {

		var inputs_are_valid = true;
		//check username
		inputs_are_valid = inputs_are_valid && (CheckInputFieldLength(username_field, 6, 30));
		//
		inputs_are_valid = inputs_are_valid && CheckInputFieldLength(address_field, 6, 30);
		inputs_are_valid = inputs_are_valid && CheckEmailField(email_field);
		await sleep(500);
		if (inputs_are_valid)
			alert("Thank you for registering for membership!");
	}

});


export { is_email_valid };