
class GuitarModel {

    /**
     * guitar_title,guitar_desc, image_path is in string
     * price is numeric
     * 
     */
    constructor(guitar_title, guitar_desc, price, image_path) {
        this.guitar_title = guitar_title;
        this.guitar_desc = guitar_desc;
        this.price = price;
        this.image_path = image_path;
    }
}

class GuitarManager {

    /**
     * gui
     * [guitar_category_map] : is a table of <string,GuitarModel[]>
     * 
     */
    constructor(guitar_category_map) {
        this.guitar_category_map = guitar_category_map;
    }

}

function GuitarModelArrToHtml(guitar_list) {

    var shown_html = ``;
    for (var i = 0; i < guitar_list.length; i++) {

        var guitar_html_template =
            `
            <div class="guitar">
                <div class="image1">
                    <img src="${guitar_list[i].image_path}" alt="">
                </div>
                <div class="desc">
                    <div class="guitar-desc">
                        <h1> ${guitar_list[i].guitar_title}</h1>
                        <p> ${guitar_list[i].guitar_desc}</p>
                        <h2> $ ${guitar_list[i].price}</h2>
                    </div>
                </div>
                <div class="star">
                    <img src="./Assets/Star.png" alt="">
                </div>
            </div>
            `;
        shown_html += guitar_html_template;
    }
    return shown_html;

}
/** 
 *  read [guitar_data_map] map 's data, convert each to html 
*/
function GuitarModelMapToHtml(guitar_data_map) {
    var shown_html = ``;
    for (const [key, value] of guitar_data_map.entries()) {
        var guitar_list = value;
        shown_html += `<center>`;//add center
        shown_html += GuitarModelArrToHtml(guitar_list)
        shown_html += `</center>`; //close cneter
    }
    return shown_html;
}
// this is where  the guitar will be shown
const guitar_shown_element = document.getElementById("guitar_shown");

//====================================== Data loading =========================================
//create the map between a list and a category
// it is map of <string, GuitarModel[]>
var guitar_data_map = new Map();

// read guitar's data from json  and load it to guitar_data_map
fetch('guitar_data.json')
    .then(response => response.json())
    .then(function (jsonResponse) {
        console.log(jsonResponse);
        guitar_data_map = new Map(Object.entries(jsonResponse));
        //load all guitar as default
        guitar_shown_element.innerHTML = GuitarModelMapToHtml(guitar_data_map);


    });



// add our change event function to our dropdown

const dropdown = document.getElementById("category-select");

dropdown.addEventListener("change", (event) => {

    var category_name = event.target.value
    console.log(`You are seeing ${event.target.value}`)
    if (category_name === "All")
        //load all guitar as default
        guitar_shown_element.innerHTML = GuitarModelMapToHtml(guitar_data_map);
    else if (!guitar_data_map.has(category_name))
        alert(`Key ${category_name} doesn't exist`);
    else {
        var guitar_list = guitar_data_map.get(category_name);
        console.log(` getting guitar list : ${guitar_list}`);
        //load each guitar and append it to the inner html of 
        //[guitar_shown_element]
        var shown_html = ``;
        // =============================== create the html =======================
        shown_html += `<center>`;//add center
        shown_html += GuitarModelArrToHtml(guitar_list)
        shown_html += `</center>`; //close cneter
        // =========================================================================
        guitar_shown_element.innerHTML = shown_html;
    }


});



