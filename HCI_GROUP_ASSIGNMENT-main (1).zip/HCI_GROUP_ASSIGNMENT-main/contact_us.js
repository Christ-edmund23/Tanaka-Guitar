import {is_email_valid} from './member_script.js';

const sleep = ms => new Promise(r => setTimeout(r, ms));
//
const form = document.getElementById('form');
const username_field = document.getElementById('username');
const email_field = document.getElementById('email');
const address_field = document.getElementById('phone-number');
const message_field = document.getElementById('message_field');


function showError(input, message) {
	const formControl = input.parentElement;
	formControl.className = 'form-control error';
	const small = formControl.querySelector('small');
	small.innerText = message;
}

function showSuccess(input) {
	const formControl = input.parentElement;
	formControl.className = 'form-control success';
}

function CheckEmailField(input) {
	if (is_email_valid(input.value.trim())) {
		showSuccess(input);
		return true;
	} else {
		showError(input, 'Email is not valid');
		return false;
	}
}

function is_fieldset_with_radio_options_empty(fieldset) {
	var options_arr = fieldset.elements;
	for (var i = 0; i < options_arr.length; i++) {
		// if one of option is checked, then it is not empty
		if (options_arr[i].checked) return false;
	}
	return true;

}

function has_field_been_filled(inputArr) {
	var has_been_filled_count = 0;
	inputArr.forEach(function (input) {
		var field_is_empty = false;
		field_is_empty = input.value.trim() === '';
		if (field_is_empty) {
			showError(input, `${getFieldName(input)} is required`);
		} else {
			has_been_filled_count++;
			showSuccess(input);
		}
	});
	// check if all field has been field
	return inputArr.length == has_been_filled_count;
}

// return true if field is between min and max (exclusive)
function CheckInputFieldLength(input, min, max) {
	if (input.value.length < min) {
		showError(
			input,
			`${getFieldName(input)} must be at least ${min} characters`
		);
		return false;
	} else if (input.value.length > max) {
		showError(
			input,
			`${getFieldName(input)} must be less than ${max} characters`
		);
		return false
	} else {
		showSuccess(input);
		return true;
	}
}


function getFieldName(input) {
	return input.id.charAt(0).toUpperCase() + input.id.slice(1);
}

form.addEventListener('submit', async function (e) {
	e.preventDefault();

	if (has_field_been_filled([username_field, email_field, address_field, message_field])) {

		var inputs_are_valid = true;
		//check username
		inputs_are_valid = inputs_are_valid && (CheckInputFieldLength(username_field, 6, 30));
		//
		inputs_are_valid = inputs_are_valid && CheckInputFieldLength(address_field, 6, 30);
		inputs_are_valid = inputs_are_valid && CheckEmailField(email_field);
		await sleep(500);
		if (inputs_are_valid)
			alert("Thank you for contacting us, we will reach you out soon!");
	}

});
