/**
 * use this script to insert the navbar directly to the html pages 
 * 
 * like "<script src= "navbar.js"></script>"
 * 
 * Not optimized
 * 
 */

// ======================= inserting the navbar =================
let html_body = document.getElementsByTagName("body")[0];

let navbar_html =
`

  <!-- ========= injected using navbar.js ============-->
  <div class="nav-bar">
    <div class="logo">
      <a href="home.html"><img src="./Assets/Tanaka Guitar.png" alt=""></a>
    </div>

    <button id="menu">
      <img src="menu.png">
    </button>

    <div class="nav-menu">
      <a href="home.html">Home</a>
      <a href="gallery.html">Gallery</a>
      <a href="member.html">Member</a>
      <a href="about-us.html">About Us</a>
      <a href="contact_us.html">Contact Us</a>
    </div>
  </div>
  <!-- ============================================== -->
`;
// insert navbar at the top
html_body.insertAdjacentHTML("afterbegin",navbar_html);
//===  get menu of navbar    ===========================
let menu = document.getElementById("menu")
//=====================================================
// add events for responsiveness
let menuState = 'close'
menu.addEventListener("click", (ev) => {
	if (menuState === 'close') {
		document.querySelector(".nav-menu").style.display = "flex"
		menuState = 'open'
	}
	else {
		document.querySelector(".nav-menu").style.display = "none"
		menuState = 'close'

	}
})

window.addEventListener('resize', (ev) => {
	if (window.innerWidth > 900) {
		document.querySelector(".nav-menu").style.display = "block"
		menuState = 'close'
	}
	else {
		document.querySelector(".nav-menu").style.display = "none"
		menuState = 'close'
	}
})

